﻿Option Explicit On
Option Strict On
Option Infer Off
Imports System.IO
Imports GridLib
' *****************************************************************
' Team Number: 17
' Team Member 1 Details: Musto, M.C.M (219104286)
' Team Member 2 Details: Bookatz, M.A (220141423)
' Team Member 3 Details: Haag, J.O (220149181)
' Team Member 4 Details: Levin, M (220001291)
' Practical: Team Project
' Class name: frm_Main
' *****************************************************************


Public Class frm_Main
    Private localFile As FileStream
    Private Sub frm_Main_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btn_Load_Click(sender As Object, e As EventArgs) Handles btn_Load.Click
        Dim better As BetterGrid
        better = New GridLib.BetterGrid(grid)
        better.EnterGrid(0, 0, "Test")
    End Sub
End Class
