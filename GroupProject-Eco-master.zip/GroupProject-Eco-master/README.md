# GroupProject-Eco
This is the repository for the Informatics group project.
